import React from "react";


export default function TesteReact() {
  return (
    <h1>Teste</h1>
  );
}
